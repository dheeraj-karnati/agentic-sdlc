# FinPay API Design — Key Endpoints
# Version: v1 | Format: OpenAPI 3.1 summary

## Authentication
- Header: Authorization: Bearer {api_key}
- Scoped keys: pk_live_* (publishable), sk_live_* (secret), rk_live_* (restricted)
- Sandbox keys: pk_test_*, sk_test_*

## Endpoints

### Merchants
POST   /v1/merchants                    # Create merchant
GET    /v1/merchants                    # List merchants (cursor pagination)
GET    /v1/merchants/{id}               # Get merchant
PATCH  /v1/merchants/{id}               # Update merchant
POST   /v1/merchants/{id}/verify        # Submit verification documents
GET    /v1/merchants/{id}/balance       # Get real-time balance

### Payments
POST   /v1/payments                     # Create payment (requires Idempotency-Key)
GET    /v1/payments/{id}                # Get payment status
POST   /v1/payments/{id}/capture        # Capture authorized payment
POST   /v1/payments/{id}/cancel         # Cancel/void authorized payment
POST   /v1/payments/{id}/refund         # Full or partial refund
GET    /v1/payments                     # List payments (filters: merchant, status, date range)

### Payouts
POST   /v1/payouts                      # Create manual payout
GET    /v1/payouts/{id}                 # Get payout status
GET    /v1/payouts                      # List payouts
GET    /v1/payouts/{id}/transactions    # Transactions included in payout

### Ledger
GET    /v1/ledger/accounts/{merchant_id}        # Account balances
GET    /v1/ledger/transactions                   # Journal entries (filters: account, date, type)
GET    /v1/ledger/statements/{merchant_id}       # Monthly statements

### Webhooks
POST   /v1/webhooks                     # Create webhook endpoint
GET    /v1/webhooks                     # List webhook endpoints
DELETE /v1/webhooks/{id}                # Delete webhook endpoint
GET    /v1/webhooks/{id}/deliveries     # View delivery history with payloads
POST   /v1/webhooks/{id}/test           # Send test event

### Risk
GET    /v1/risk/scores/{payment_id}     # Get risk score for payment
POST   /v1/risk/rules                   # Create custom risk rule
GET    /v1/disputes                     # List chargebacks/disputes
POST   /v1/disputes/{id}/evidence       # Submit dispute evidence

## Error Format (RFC 7807)
{
  "type": "https://api.finpay.com/errors/insufficient-funds",
  "title": "Insufficient funds",
  "status": 402,
  "detail": "The merchant's available balance ($45.00) is less than the requested payout ($100.00).",
  "instance": "/v1/payouts/po_abc123"
}

## Webhooks Events
merchant.created, merchant.verified, merchant.suspended
payment.created, payment.authorized, payment.captured, payment.failed, payment.refunded
payout.created, payout.completed, payout.failed
dispute.created, dispute.updated, dispute.won, dispute.lost
account.balance_updated
