# FinPay — Sample User Stories (Sprint 1-3)
# Author: Product Team | Date: March 2026

## Epic 1: Merchant Onboarding

### US-101: As a platform, I want to onboard a new merchant via API so they can start accepting payments
**Acceptance Criteria:**
- Given a valid merchant payload with business_name, business_type, owner information, and bank account
- When POST /v1/merchants is called
- Then a merchant record is created with status "pending_verification"
- And KYC/KYB verification is initiated asynchronously
- And a webhook "merchant.created" is sent to the platform
- And the merchant receives a welcome email

### US-102: As a merchant, I want to complete KYC verification so I can receive payouts
**AC:**
- Given a merchant in "pending_verification" status
- When the merchant submits identity documents (government ID + selfie)
- Then the identity verification service processes the submission
- And if verified: merchant status → "active", webhook "merchant.verified" sent
- And if rejected: merchant status → "verification_failed", reason provided

### US-103: As a platform admin, I want to view merchant onboarding status so I can track pipeline
**AC:**
- Given I am on the merchant management page
- When I view the merchant list
- Then I see: name, status (pending/active/suspended/rejected), onboarding date, verification status

## Epic 2: Payment Processing

### US-201: As a platform, I want to create a payment via API so my customers can pay merchants
**AC:**
- Given valid payment details (amount, currency, payment_method, merchant_id)
- When POST /v1/payments is called with Idempotency-Key header
- Then a payment is created with status "pending"
- And the payment method is authorized
- And on success: status → "authorized", webhook "payment.authorized" sent
- And on failure: status → "failed", decline reason provided

### US-202: As a platform, I want to capture an authorized payment
**AC:**
- Given an authorized payment
- When POST /v1/payments/{id}/capture is called
- Then funds are captured from the payment method
- And ledger entries created: debit customer, credit merchant pending
- And webhook "payment.captured" sent

### US-203: As a platform, I want to refund a payment
**AC:**
- Given a captured payment
- When POST /v1/payments/{id}/refund is called (full or partial amount)
- Then refund is processed to original payment method
- And ledger entries reversed proportionally
- And webhook "payment.refunded" sent
- And merchant available balance reduced by refund amount

## Epic 3: Payouts

### US-301: As a merchant, I want to receive automatic daily payouts
**AC:**
- Given a merchant with available balance > $0 and payout schedule = "daily"
- When the nightly payout job runs at 6 PM ET
- Then an ACH credit is initiated for the available balance minus reserves
- And payout status = "pending" until bank confirms (typically T+2)
- And webhook "payout.created" sent

### US-302: As a merchant, I want to request an instant payout
**AC:**
- Given a merchant with available balance > $10
- When POST /v1/payouts with method="instant" is called
- Then an RTP transfer is initiated (completes in < 30 seconds)
- And a $0.50 fee is deducted from the payout amount
- And webhook "payout.completed" sent within 60 seconds
