# FinPay Compliance Requirements
# Author: Legal & Compliance Team | Date: March 2026

## Regulatory Framework

### Federal Requirements
1. FinCEN MSB registration (completed)
2. Bank Secrecy Act (BSA) compliance
3. USA PATRIOT Act: CIP (Customer Identification Program)
4. OFAC sanctions screening on all merchants and payees
5. 1099-K reporting for merchants exceeding $600/year (IRS threshold effective 2024)
6. CFPB oversight for consumer financial products

### State Requirements
- Money transmitter licenses required in 49 states + DC + territories
- Currently operating under sponsor bank license (Column or Evolve Bank)
- Plan to obtain own licenses starting 2027 in top 10 states by volume
- State-specific requirements: surety bonds, net worth, reporting

### Card Network Requirements
- PCI DSS Level 1 compliance (annual QSA audit)
- Visa/Mastercard merchant monitoring programs
- Chargeback rate monitoring: alert at 0.9%, program at 1.0%, termination risk at 1.8%
- Fraud rate monitoring: similar thresholds

### International (Phase 2)
- GDPR for EU merchants (data residency, right to erasure, DPO appointment)
- PSD2/SCA for European card payments (strong customer authentication)
- Open Banking API compliance (PSD2 Article 36)
- UK FCA registration for payment services

## KYC/KYB Requirements

### Individual Merchants (KYC)
Required information:
- Full legal name, date of birth, SSN (US) or national ID
- Residential address (verified via document or database)
- Government-issued photo ID (passport, driver's license, state ID)
- Selfie for liveness verification (anti-spoofing)

Verification levels:
- Level 1 (< $10K/month): Name + DOB + SSN check only
- Level 2 (< $100K/month): Level 1 + ID document + selfie
- Level 3 (unlimited): Level 2 + address verification + enhanced due diligence

### Business Merchants (KYB)
Required information:
- Business legal name, DBA, EIN
- Business address, phone, website
- State of incorporation, formation date
- Business type (LLC, Corp, Sole Prop, Partnership, Non-profit)
- All beneficial owners with 25%+ ownership (KYC on each)
- Business bank account (verified via micro-deposits or Plaid)

## Transaction Monitoring
- All transactions screened against OFAC SDN list in real-time
- Unusual activity detection rules:
  - Single transaction > $10,000 (CTR threshold)
  - Aggregate transactions > $10,000 in 24 hours from same source
  - Rapid succession of transactions (structuring detection)
  - Geographic anomalies (transaction from unusual location)
  - Merchant category anomalies (sudden change in business type)
- SAR filing within 30 days of detection
- Record retention: 5 years for all transaction records, KYC documents, and SARs

## Data Handling
- PCI cardholder data: never stored on FinPay servers (tokenized via Basis Theory)
- SSN/EIN: encrypted at rest (AES-256), column-level encryption, access logged
- KYC documents: stored in S3 with SSE-KMS encryption, auto-deleted after 5 years
- Audit trail: all access to PII logged with user, timestamp, purpose
- Data breach notification: within 72 hours per state law requirements
