# Product Requirements Document
# FinPay — Embedded Payment Infrastructure Platform
# Version: 1.0 | Author: Amit Sharma, CPO | Date: March 2026

## 1. Vision

FinPay is a B2B embedded payment infrastructure platform that enables SaaS companies to offer payment acceptance, money movement, and financial accounts to their end users without building payments from scratch. Think "Stripe for vertical SaaS" — but with multi-currency support, embedded lending, and real-time ledger capabilities.

Target market: Vertical SaaS platforms (property management, healthcare billing, logistics, freelancer marketplaces) with 500-50,000 business customers needing payment capabilities.

## 2. Core Capabilities

### 2.1 Payment Acceptance (PAY-1xx)
- PAY-101: Accept credit/debit cards (Visa, Mastercard, Amex, Discover) via tokenized card vault
- PAY-102: Accept ACH bank transfers (debit and credit) with Plaid account verification
- PAY-103: Accept wire transfers (domestic USD and international SWIFT)
- PAY-104: Accept digital wallets: Apple Pay, Google Pay, PayPal
- PAY-105: Support recurring billing: fixed amount, usage-based, tiered pricing
- PAY-106: Support payment links: hosted checkout pages with customizable branding
- PAY-107: Support invoicing: create, send, track, and auto-remind for payment
- PAY-108: Support payment splitting: single payment distributed to multiple recipients (marketplace model)
- PAY-109: Support partial payments and installment plans
- PAY-110: Real-time payment status webhooks to platform
- PAY-111: Support 3D Secure 2.0 authentication for card payments
- PAY-112: Support idempotency keys on all payment creation endpoints to prevent duplicate charges
- PAY-113: Support automatic retry logic for failed recurring payments (smart retry based on historical success patterns)
- PAY-114: Support payment method on file with PCI DSS Level 1 tokenization
- PAY-115: Support multi-currency acceptance: USD, EUR, GBP, CAD, AUD, JPY, MXN (minimum)

### 2.2 Money Movement (MOV-1xx)
- MOV-101: Platform-to-merchant payouts via ACH (2-day), same-day ACH, or RTP (instant)
- MOV-102: Configurable payout schedules: daily, weekly, biweekly, monthly, or manual
- MOV-103: Payout holds for risk review with configurable hold periods
- MOV-104: Multi-party settlement: split a transaction's funds across multiple parties with configurable splits (percentage or fixed amount)
- MOV-105: Reserve management: hold a percentage of merchant funds as rolling reserve for chargebacks
- MOV-106: Cross-border payouts to 40+ countries via partner bank network
- MOV-107: Automated 1099 reporting for US merchant payouts exceeding $600/year
- MOV-108: Payout reconciliation API: match payouts to original transactions
- MOV-109: Negative balance recovery: if merchant balance goes negative (chargebacks), automatically deduct from future payouts or debit connected bank account

### 2.3 Financial Accounts (ACC-1xx)
- ACC-101: Virtual accounts (FBO — For Benefit Of) for each merchant on the platform
- ACC-102: Real-time ledger: every money movement creates double-entry journal entries
- ACC-103: Account balance API: real-time available balance, pending balance, reserved balance
- ACC-104: Transaction history with filtering, search, and export (CSV, PDF)
- ACC-105: Multi-currency accounts: hold and convert between supported currencies
- ACC-106: Interest-bearing accounts for platform's pooled funds (revenue share with platforms)
- ACC-107: Account statements: monthly, downloadable, with transaction detail
- ACC-108: Sub-accounts: merchants can create sub-accounts for departments or locations

### 2.4 Risk & Compliance (RSK-1xx)
- RSK-101: Real-time transaction risk scoring using ML model (fraud probability 0-100)
- RSK-102: Velocity checks: configurable limits per card, per merchant, per time window
- RSK-103: Address Verification Service (AVS) and CVV verification on all card transactions
- RSK-104: Chargeback management: receive alerts, submit evidence, track outcomes
- RSK-105: KYC/KYB onboarding: identity verification for individuals (KYC) and businesses (KYB)
- RSK-106: Sanctions screening: OFAC SDN list, EU sanctions, PEP screening
- RSK-107: Suspicious activity monitoring and SAR filing support
- RSK-108: PCI DSS Level 1 compliance for all card data handling
- RSK-109: SOC 2 Type II certification
- RSK-110: AML program with transaction monitoring rules engine
- RSK-111: Configurable risk rules per platform: each platform can set their own velocity limits, blocked countries, and minimum transaction amounts
- RSK-112: Device fingerprinting and IP geolocation for fraud signals

### 2.5 Platform Integration (INT-1xx)
- INT-101: RESTful API with OpenAPI 3.1 specification
- INT-102: Official SDKs: Python, JavaScript/TypeScript, Ruby, Go, Java, PHP, .NET
- INT-103: Webhooks with retry logic (exponential backoff, 24-hour retry window), HMAC signature verification, and event replay
- INT-104: Embeddable UI components (React, Vue): payment form, payout dashboard, transaction table, account balance widget
- INT-105: OAuth 2.0 platform authentication with scoped API keys (read, write, admin)
- INT-106: Sandbox environment with test cards, test bank accounts, and simulated edge cases (declines, chargebacks, disputes)
- INT-107: API versioning with 12-month deprecation notice
- INT-108: Rate limiting: 1000 requests/minute per API key, configurable per platform
- INT-109: GraphQL API (optional, alongside REST)
- INT-110: Hosted onboarding flow: platform embeds a URL, FinPay handles KYC/KYB data collection and verification

### 2.6 Platform Dashboard (DSH-1xx)
- DSH-101: Real-time payments dashboard: volume, revenue, success rate, decline reasons
- DSH-102: Merchant management: view, search, filter, onboarding status, risk status
- DSH-103: Payout management: scheduled, completed, failed payouts with drill-down
- DSH-104: Financial reporting: revenue, fees, reserves, net settlement amounts
- DSH-105: Risk dashboard: fraud alerts, chargeback rate, suspicious activity
- DSH-106: Developer portal: API docs, SDK downloads, webhook logs, API key management
- DSH-107: Audit log: all administrative actions with user, timestamp, and IP
- DSH-108: White-label dashboard for platform's merchants (fully brandable)

## 3. Technical Requirements

### 3.1 Architecture
- Event-driven microservices architecture
- Event sourcing for all financial transactions (append-only, immutable)
- CQRS (Command Query Responsibility Segregation) for read/write optimization
- PostgreSQL for OLTP, ClickHouse for analytics
- Apache Kafka for event streaming
- Redis for caching and rate limiting
- Kubernetes on AWS EKS for orchestration

### 3.2 Performance
- API p99 latency: < 200ms for payment creation
- Webhook delivery: < 5 seconds from event to first delivery attempt
- Dashboard page load: < 2 seconds
- Support 10,000 transactions per second at peak
- 99.99% uptime SLA for payment processing
- Zero data loss guarantee (event sourcing + WAL replication)

### 3.3 Security
- PCI DSS Level 1 (handled via tokenization partner: Basis Theory or VGS)
- SOC 2 Type II certification
- Encryption at rest (AES-256) and in transit (TLS 1.3, minimum TLS 1.2)
- HSM for cryptographic key management
- API key rotation without downtime
- IP allowlisting option per API key
- Secrets management via AWS Secrets Manager

### 3.4 Compliance
- Money transmitter licenses: initially operate under sponsor bank, pursue own licenses in 2027
- FinCEN registration as MSB
- State-by-state compliance monitoring
- GDPR compliance for European merchants
- PSD2/SCA compliance for European card payments
- Consumer Financial Protection Bureau (CFPB) oversight awareness

## 4. Monetization
- Per-transaction fee: 2.9% + $0.30 for cards, 0.8% capped at $5 for ACH
- Monthly platform fee: $0 (free tier), $499 (growth), $2,499 (enterprise)
- Interchange-plus pricing available for enterprise
- FX markup: 1% above mid-market rate for currency conversion
- Instant payout fee: $0.50 per payout (vs free for standard 2-day)
- Revenue share: 50% of net interchange on card transactions to platforms (enterprise)
