# Technical Architecture Document — FinPay
# Author: Engineering Team | Date: March 2026

## System Architecture

### Core Services (Microservices)
1. **payment-service**: Payment creation, processing, status management
2. **payout-service**: Merchant payouts, settlement, reconciliation
3. **ledger-service**: Double-entry accounting, real-time balances
4. **risk-service**: Fraud scoring, velocity checks, rule engine
5. **identity-service**: KYC/KYB, sanctions screening, onboarding
6. **webhook-service**: Event delivery, retry, signature verification
7. **api-gateway**: Authentication, rate limiting, request routing
8. **merchant-service**: Merchant CRUD, configuration, hierarchy
9. **reporting-service**: Analytics, financial reports, 1099 generation
10. **notification-service**: Email, SMS, push notifications
11. **fx-service**: Currency conversion, rate management
12. **dispute-service**: Chargeback management, evidence submission

### Data Architecture
- **PostgreSQL 16**: Primary OLTP database (payment-service, merchant-service, ledger-service)
- **Apache Kafka**: Event streaming backbone — all services publish events
- **ClickHouse**: Analytics OLAP database — populated via Kafka consumers
- **Redis**: Session cache, rate limiting counters, idempotency keys
- **S3**: Document storage (KYC documents, dispute evidence, statements)
- **ElasticSearch**: Transaction search, merchant search, log aggregation

### Event Sourcing Design
- All financial mutations are events, not updates
- Event store is append-only PostgreSQL table
- Current state derived from event replay
- Events: PaymentCreated, PaymentAuthorized, PaymentCaptured, PaymentRefunded, PayoutInitiated, PayoutCompleted, etc.
- Snapshots every 100 events per aggregate for performance

### Ledger Design
- Double-entry accounting: every transaction creates minimum 2 journal entries
- Account types: Asset, Liability, Revenue, Expense
- Key accounts per merchant: Available, Pending, Reserve, Fees
- All entries immutable — corrections via reversal entries
- Real-time balance computation from journal entries
- End-of-day reconciliation with partner bank

### API Design
- REST + OpenAPI 3.1
- Versioned: /v1/, /v2/
- Authentication: API key (header) or OAuth 2.0 bearer token
- Idempotency: Idempotency-Key header required on POST/PUT
- Pagination: cursor-based (not offset)
- Rate limiting: token bucket algorithm, 1000 req/min default
- Error format: RFC 7807 Problem Details

### Infrastructure
- AWS EKS (Kubernetes) for all services
- AWS RDS for PostgreSQL (Multi-AZ)
- AWS MSK for Kafka
- AWS ElastiCache for Redis
- CloudFront CDN for dashboard and embeddable components
- AWS WAF for API protection
- Terraform for all infrastructure-as-code
- GitHub Actions for CI/CD
- Datadog for monitoring, alerting, APM
- PagerDuty for incident management

### Security Architecture
- Zero-trust network: service mesh with mTLS (Istio)
- API keys hashed at rest (bcrypt), displayed once at creation
- PCI cardholder data environment (CDE) isolated in separate VPC
- Card data never touches FinPay servers — tokenized via Basis Theory
- All secrets in AWS Secrets Manager, rotated quarterly
- Penetration testing: quarterly by NCC Group or equivalent
- Bug bounty program via HackerOne
