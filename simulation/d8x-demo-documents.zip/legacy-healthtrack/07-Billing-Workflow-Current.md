# Current Billing Workflow Documentation
# Author: Robert Kim, Billing Manager | Date: February 2026

## Current State Workflow

### Daily Charge Capture (Manual)
1. Physician sees patient, writes clinical note
2. Billing specialist reviews note next business day (24-48 hour delay)
3. Specialist manually selects CPT codes based on note content
4. Specialist manually enters ICD-10 codes from assessment section
5. Common error: undercoding E&M visits (coding 99213 when documentation supports 99214)
6. Estimated annual revenue loss from undercoding: $200,000-$400,000

### Claim Submission (Nightly Batch)
1. Claims batched at 11 PM nightly via Windows Task Scheduler
2. EDI 837P file generated from billing_claims table
3. SFTP upload to Availity clearinghouse
4. No real-time validation — errors discovered 3-5 days later
5. Current denial rate: 18% (industry benchmark: 5-10%)

### Top Denial Reasons
| Reason | % of Denials | Root Cause |
|--------|-------------|------------|
| Diagnosis doesn't support procedure | 32% | Manual code selection errors |
| Missing prior authorization | 24% | No auth tracking system |
| Timely filing exceeded | 15% | Batch delays + resubmission lag |
| Patient not eligible on DOS | 12% | No real-time eligibility check |
| Duplicate claim | 8% | Rebilling without checking status |
| Missing documentation | 9% | Notes not completed before billing |

### Payment Processing
- ERA (835) files received from Availity weekly
- Manually imported into system — no auto-posting
- Patient balance calculation is manual
- Payment plans tracked in Excel (400+ active plans)
- Collections referral: manual review at 120 days
- Write-off approval: manager review for amounts > $500

### Key Pain Points
1. No real-time eligibility = $15/min staff time wasted per patient
2. No prior auth tracking = 24% of denials
3. No auto-coding = undercoding + 32% of denials
4. No auto-posting = 2 FTE dedicated to payment posting
5. Excel payment plans = no automated follow-up
6. Approval threshold discrepancy: system has $5,000, management says $10,000

### Financial Impact
- Annual charges: $34M
- Annual collections: $28.5M (83.8% collection rate)
- Lost to denials: $5.5M gross (recovered $2.1M on appeal)
- Net denial loss: $3.4M annually
- Target with new system: reduce to < $1M denial loss
