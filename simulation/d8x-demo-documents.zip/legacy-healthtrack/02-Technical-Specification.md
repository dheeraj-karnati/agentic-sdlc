# Technical Specification — HealthTrack Pro Legacy System
# Author: Michael Torres, IT Director | Date: February 2026

## 1. Current Architecture

### Technology Stack
- Frontend: Classic ASP (VBScript) + ASP.NET WebForms (.NET 2.0)
- Backend: COM+ components in Visual Basic 6.0
- Database: SQL Server 2008 R2 Standard (SP3, unsupported since July 2019)
- Reporting: Crystal Reports XI (unsupported since 2016)
- Web Server: IIS 6.0 on Windows Server 2008 R2
- Authentication: Windows Auth (Active Directory)
- File Storage: \\fileserver01\patient-docs (no encryption)

### Infrastructure
- APP01: Dell R710, 32GB RAM, 8 cores (web/app server)
- DB01: Dell R720, 64GB RAM, 16 cores, SAS (database)
- No redundancy, no failover, no load balancing
- Backup: nightly full to tape, weekly offsite
- No disaster recovery site
- Network: 1 Gbps internal, 100 Mbps internet (shared with corporate)

### Database Statistics (as of Feb 2026)
- Total size: 2.3 TB
- clinical_notes: 42M rows (780 GB) — nvarchar(max) note text
- patient_documents: 8M rows (890 GB) — varbinary(max) BLOBs
- audit_log: 95M rows (340 GB) — never purged since 2009
- appointment_history: 18M rows (120 GB)
- billing_claims: 8.1M rows (45 GB)
- patients: 243K rows (12 GB) — includes 63K inactive
- 47 missing indexes (SQL tuning wizard)
- 23 stored procedures exceeding 500 lines
- 8 triggers on patients table
- No partitioning, no columnstore indexes

### Critical Technical Debt
1. SSN stored plaintext: patients.ssn VARCHAR(11)
2. Passwords: MD5 hash without salt in users.password_hash
3. SQL injection: 60% of ASP pages use string concatenation
4. Session bleed: Application-level session state causes cross-user data
5. BLOBs in DB: PDF/images as varbinary(max) — primary DB size driver
6. No connection pooling: each request opens new DB connection
7. Silent errors: "On Error Resume Next" throughout VB6 codebase
8. Date chaos: mix of VARCHAR dates ('03/15/2026') and DATETIME columns
9. Encoding issues: VARCHAR/NVARCHAR mix causes mojibake in non-ASCII names
10. Hardcoded clinic IDs: adding a clinic requires code changes in 47 files

### Performance Benchmarks
| Operation | Current avg | 95th pct | Target |
|-----------|-------------|----------|--------|
| Patient search | 2.1s | 8.4s | < 500ms |
| Schedule load | 3.8s | 12.1s | < 1s |
| Note save | 1.2s | 4.7s | < 500ms |
| Lab results | 4.5s | 15.2s | < 1s |
| Report gen | 45s | 180s | < 10s |
| Login | 3.2s | 9.8s | < 2s |

Peak: Mon 8-11 AM, 280-320 concurrent users
DB CPU during peak: 85-95%
Buffer pool hit ratio: < 90% (should be > 99%)

## 2. Security Audit Findings (Q4 2025)

### Critical (must fix before go-live)
- SEC-01: SSN plaintext storage (all 243K patient records)
- SEC-02: Unpatched SQL Server (CVE-2023-21528, CVE-2023-38169, CVE-2024-37334)
- SEC-03: SQL injection in sp_SearchPatients and 34 ASP pages
- SEC-04: No encryption at rest (HIPAA violation)
- SEC-05: No audit trail for record access (HIPAA violation)

### High
- SEC-06: MD5 password hashing without salt
- SEC-07: No MFA for any user role
- SEC-08: Session timeout not enforced (sessions persist indefinitely)
- SEC-09: No TLS for internal database connections
- SEC-10: File share permissions too broad (all staff can access all docs)

### Medium
- SEC-11: No account lockout policy
- SEC-12: No password complexity requirements
- SEC-13: Departed employee accounts not disabled (47 found active)
- SEC-14: Crystal Reports server exposes data via unprotected URL
- SEC-15: Error messages expose stack traces and SQL to users

## 3. Integration Points

### Current (all manual or batch)
1. Insurance eligibility: manual phone/web portal check
2. Lab orders: fax-based, results manually entered (3.2% error rate)
3. E-prescribing: separate Surescripts terminal (not integrated)
4. Claims: nightly EDI 837P batch to Availity (18% denial rate)
5. Patient communication: all manual calls/letters
6. State immunization registry: quarterly CSV upload

### Required New Integrations
1. LabCorp FHIR R4 API — bidirectional
2. Quest Diagnostics FHIR R4 API — bidirectional
3. BioReference REST API — proprietary format
4. Surescripts NCPDP SCRIPT 2017071 — e-prescribing + EPCS
5. First Databank API — drug interaction checking
6. Stripe Connect — patient payments (PCI DSS scope)
7. Twilio — SMS reminders and notifications
8. SendGrid — email notifications
9. NC-IIS / VA-VIIS — immunization registry reporting
10. PDMP (Prescription Drug Monitoring Program) — NC and VA
11. Okta/Auth0 — identity management, SSO, MFA
12. AWS S3 — document storage
13. Direct Secure Messaging — provider-to-provider (via DirectTrust)
