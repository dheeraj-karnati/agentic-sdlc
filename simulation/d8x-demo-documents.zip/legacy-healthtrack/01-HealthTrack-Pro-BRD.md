# Business Requirements Document
# HealthTrack Pro — Enterprise Patient Management System
# Version: 3.2 | Status: Board Approved
# Author: Sarah Chen, VP of Product | Date: March 2026

---

## 1. Executive Summary

HealthTrack Pro is a critical modernization initiative to replace our 17-year-old patient management system (Classic ASP / VB6 / SQL Server 2008 R2) serving 47 clinics across North Carolina and Virginia. The system manages 180,000 active patients, processes 2,400 daily appointments, handles $34M annual billing, and employs 320 clinical and administrative staff.

The legacy system has reached end-of-life: vendor support expired in 2024, three unpatched CVEs exist, SSNs are stored in plaintext, and we cannot meet updated HIPAA requirements for encryption at rest. A recent penetration test identified 14 critical vulnerabilities.

Budget: $1.2M | Timeline: 12 months | Target go-live: March 2027

---

## 2. Business Objectives

- BO-01: Migrate 100% of active patient data with zero data loss
- BO-02: Reduce appointment scheduling time from 4.2 min to < 90 seconds
- BO-03: Enable patient self-service for 60% of appointment bookings within 6 months of launch
- BO-04: Achieve HIPAA compliance certification by December 2026
- BO-05: Reduce billing claim denial rate from 18% to under 5%
- BO-06: Reduce IT maintenance costs by 40% through cloud hosting
- BO-07: Enable mobile access for all 89 physicians
- BO-08: Integrate with 3 external lab systems within 90 days of launch
- BO-09: Reduce average lab result turnaround from 4-6 hours to under 15 minutes
- BO-10: Eliminate paper-based processes (currently 23 identified paper workflows)

---

## 3. Stakeholders

| Role | Name | Interest | Authority |
|------|------|----------|-----------|
| Executive Sponsor | Dr. James Wright, CMO | Clinical quality and patient safety | Final approval on clinical workflows |
| Product Owner | Sarah Chen, VP Product | Feature prioritization and roadmap | Scope decisions |
| IT Lead | Michael Torres, IT Director | Architecture, security, infrastructure | Technical decisions |
| Compliance | Linda Park, Compliance Officer | HIPAA, state regulations, audit readiness | Compliance veto power |
| Clinical Lead | Karen Davis, Head Nurse | Nursing workflows, patient experience | Workflow validation |
| Billing Lead | Robert Kim, Billing Manager | Revenue cycle, claims, payments | Billing workflow approval |
| Physician Champion | Dr. Priya Patel, Internist | Physician adoption, clinical documentation | Physician workflow feedback |
| Patient Advisory | Martha Chen, Patient Rep | Patient portal usability | Patient experience feedback |

---

## 4. Functional Requirements

### 4.1 Patient Registration & Demographics (FR-1xx)

- FR-101: System shall support new patient registration capturing: legal name, preferred name, date of birth, biological sex, gender identity, race, ethnicity, preferred language (from ISO 639 list), marital status, and religion
- FR-102: System shall capture multiple addresses per patient: home, mailing, work, temporary (with date ranges for temporary addresses)
- FR-103: System shall capture unlimited phone numbers with type classification: home, mobile, work, fax; and contact preferences: OK to call, OK to text, OK to leave voicemail (per HIPAA)
- FR-104: System shall capture email addresses with consent tracking for: appointment reminders, lab results notification, billing statements, marketing communications (each independently togglable)
- FR-105: System shall capture emergency contacts: minimum 2 required, with name, relationship, phone, and whether authorized to receive medical information
- FR-106: System shall verify insurance eligibility in real-time via EDI 270/271 transaction with the following payers: Medicare, Medicaid (NC and VA), Blue Cross NC, Aetna, Cigna, UnitedHealthcare, Humana (minimum)
- FR-107: System shall support multiple insurance plans per patient: primary, secondary, tertiary with coordination of benefits logic
- FR-108: System shall capture insurance card images (front and back) via webcam or photo upload
- FR-109: System shall detect duplicate patients using probabilistic matching algorithm: weighted score across last name (25%), first name (20%), DOB (25%), SSN last 4 (15%), phone (10%), address (5%). Match threshold: 75% = review, 90% = block
- FR-110: System shall maintain a patient merge workflow: review duplicates, select master record, merge demographics/appointments/notes/billing with full audit trail
- FR-111: System shall capture patient photo via webcam for identity verification at check-in
- FR-112: System shall support patient self-registration via kiosk (iPad) in waiting room: demographics confirmation, insurance card photo, consent signatures
- FR-113: System shall capture employer information for workers' compensation cases
- FR-114: System shall capture referring physician information with NPI lookup
- FR-115: System shall support patient record inactivation with reason code: deceased, moved away, requested removal, duplicate, other
- FR-116: System shall maintain a complete change history for all demographic fields with before/after values, timestamp, and user who made the change
- FR-117: System shall support patient consent management: treatment consent, HIPAA notice acknowledgment, data sharing consent, telehealth consent, research participation consent — each with version tracking and re-consent workflows
- FR-118: System shall capture social determinants of health: housing status, food security, transportation access, education level, employment status — using LOINC-coded assessments
- FR-119: System shall support patient preferred pharmacy capture with NCPDP pharmacy lookup integration
- FR-120: System shall flag patients with special needs: interpreter required (with language), mobility assistance, behavioral alerts, legal guardian required for consent

### 4.2 Appointment Scheduling (FR-2xx)

- FR-201: System shall display physician availability in calendar view with configurable time slots (default: 15 minutes, configurable per physician from 5 to 60 minutes)
- FR-202: System shall prevent double-booking by checking: physician schedule, room availability, equipment availability, surgical blocks, on-call rotations, PTO, lunch blocks, administrative time, and hospital rounding schedules
- FR-203: System shall support appointment types with configurable durations: New Patient Visit (60 min), Follow-up (30 min), Annual Physical (45 min), Urgent/Same-day (15 min), Telehealth Video (30 min), Telehealth Phone (15 min), Procedure (variable, defined per procedure code), Lab Draw (10 min), Nurse Visit (20 min), Group Visit (90 min)
- FR-204: System shall enforce appointment type constraints: New Patient requires insurance verification, Procedures require prior authorization check, Controlled substance follow-up cannot exceed 90-day interval
- FR-205: System shall send automated appointment reminders: SMS at 48 hours and 2 hours before, email at 72 hours, voice call at 24 hours (configurable per clinic and per patient preference)
- FR-206: System shall support patient self-scheduling via portal with rules: only follow-up and telehealth types, only with previously seen physician, only during designated self-schedule slots, 24-hour minimum advance booking, 24-hour cancellation policy
- FR-207: System shall manage waitlist per physician: capture preferred dates/times, automatically notify next waitlist patient when slot opens (SMS + email), patient has 2 hours to confirm before next on list is notified
- FR-208: System shall support recurring appointments: weekly, biweekly, monthly, with auto-generation of future appointments up to 6 months out and conflict detection
- FR-209: System shall support walk-in queue management: add to queue with chief complaint, display estimated wait time (calculated from average visit duration by type + current queue depth), notify patient via text when ready
- FR-210: System shall support multi-provider appointments: patient sees nurse first, then physician, in sequence, in separate rooms, as a single visit
- FR-211: System shall track no-show history per patient and allow configurable no-show policies: warning letter after 2 no-shows, require deposit after 3 no-shows, dismissal review after 5 no-shows within 12 months
- FR-212: System shall support appointment check-in via: front desk manual, kiosk (iPad), mobile app QR code scan, or automatic check-in via geofencing (patient's phone detected at clinic)
- FR-213: System shall display real-time clinic status board: patients checked in, in room, with provider, checked out — visible to front desk and nursing station
- FR-214: System shall support appointment overbooking with configurable limits per physician per day (e.g., max 2 overbooks)
- FR-215: System shall support appointment templates: physicians can create weekly schedule templates with blocked times, default appointment types per slot, and effective date ranges
- FR-216: System shall calculate and display key scheduling metrics: utilization rate, average wait time, no-show rate, cancellation rate, slots available this week — per physician and per clinic
- FR-217: System shall support referring appointment scheduling: external physician refers patient, referral coordinator schedules with appropriate specialist, referring physician receives notification of scheduled date
- FR-218: System shall enforce payer-specific scheduling rules: some plans require referral on file before specialist visit can be scheduled
- FR-219: System shall support resource scheduling alongside appointments: rooms, equipment (EKG machines, ultrasound), and staff (MA assignment)
- FR-220: System shall support appointment recall lists: patients due for preventive care (annual physical, colonoscopy, mammogram) based on age, sex, diagnosis history, and last visit date

### 4.3 Clinical Documentation (FR-3xx)

- FR-301: System shall support structured clinical notes using configurable templates: SOAP Note, History & Physical (H&P), Procedure Note, Consultation Note, Discharge Summary, Progress Note, Telephone Encounter, Nursing Assessment, Pre-operative Assessment
- FR-302: System shall support voice-to-text dictation integrated into note templates (Dragon Medical One or equivalent) with inline editing
- FR-303: System shall maintain active problem list per patient using ICD-10-CM codes with: onset date, status (active/inactive/resolved), severity, treating physician, and relationship to other problems
- FR-304: System shall maintain active medication list with: drug name (brand and generic), dosage, frequency, route, start date, end date, prescribing physician, indication (linked ICD-10), refills remaining, last fill date, pharmacy, and NDC code
- FR-305: System shall perform real-time drug interaction checking on medication changes using First Databank or equivalent: drug-drug, drug-allergy, drug-condition, drug-food, therapeutic duplication, dose range checking
- FR-306: System shall track allergies with: allergen (drug, food, environmental), reaction description, severity (mild/moderate/severe/life-threatening), onset date, verified status, reported by, and cross-reactivity information
- FR-307: System shall record vital signs with normal range validation: height, weight, BMI (auto-calculated), blood pressure (systolic/diastolic), heart rate, respiratory rate, temperature, oxygen saturation, pain level (0-10). Support pediatric growth charts (CDC/WHO) for patients under 18
- FR-308: System shall display vital sign trends as interactive charts with configurable date ranges and the ability to overlay multiple vitals on one graph
- FR-309: System shall provide clinical decision support alerts: preventive care reminders (flu shot, colonoscopy), chronic disease management (HbA1c due for diabetics), medication refill reminders, abnormal vital sign alerts (e.g., BP > 180/120 flags hypertensive crisis protocol)
- FR-310: System shall support order entry: lab orders (with AOE questions), imaging orders (with clinical indication), referral orders (with reason and urgency), procedure orders, and DME orders
- FR-311: System shall support e-prescribing via Surescripts NCPDP SCRIPT 2017071 standard including: new prescriptions, renewals, change requests, cancellations, and EPCS (Electronic Prescribing for Controlled Substances) with two-factor authentication
- FR-312: System shall enforce controlled substance prescribing rules: PDMP check required before prescribing Schedule II-V, morphine milligram equivalent (MME) calculation and alert at > 90 MME/day, informed consent documentation for chronic opioid therapy
- FR-313: System shall support clinical note co-signing workflow: resident creates note → attending reviews → co-signs with attestation → note locked
- FR-314: System shall support clinical note addenda: append additional information to signed notes without modifying original text, with timestamp and author tracking
- FR-315: System shall maintain immunization records with: vaccine name, CVX code, manufacturer (MVX code), lot number, expiration date, administration site, route, administering provider, VIS (Vaccine Information Statement) given date, and submission to state immunization registry (NC-IIS and VA-VIIS)
- FR-316: System shall support clinical flowsheets for chronic disease management: diabetes (HbA1c, glucose, foot exam, eye exam), hypertension (BP readings, medication changes), asthma (peak flow, exacerbation count, medication step)
- FR-317: System shall support patient education documentation: materials provided (linked to diagnosis), comprehension assessment, teach-back verification
- FR-318: System shall support clinical image capture and annotation: wound photography with measurement tools, dermatology images, procedure documentation images — all linked to the encounter
- FR-319: System shall support advance directive documentation: living will, healthcare power of attorney, POLST/MOST form, DNR status — with expiration tracking and renewal reminders
- FR-320: System shall generate after-visit summaries (AVS) in patient-friendly language including: diagnoses discussed, medications changed, follow-up instructions, lab/imaging orders, referrals, and patient education materials. Available in English and Spanish at minimum.

### 4.4 Laboratory Integration (FR-4xx)

- FR-401: System shall support bidirectional HL7 FHIR R4 interface with LabCorp: order submission (ServiceRequest), result receipt (DiagnosticReport, Observation), order status tracking
- FR-402: System shall support bidirectional HL7 FHIR R4 interface with Quest Diagnostics: same capabilities as FR-401
- FR-403: System shall support REST API interface with BioReference Laboratories: order submission, result receipt, status polling
- FR-404: System shall automatically match incoming lab results to: ordering patient (by MRN or demographic match), ordering physician, and original order
- FR-405: System shall flag abnormal results with configurable reference ranges: below low, low, normal, high, above high, critical low, critical high — per test, per age group, per sex
- FR-406: System shall implement critical result notification: for panic values, immediately page the ordering physician via secure messaging, escalate to covering physician if not acknowledged within 15 minutes, escalate to department chief if not acknowledged within 30 minutes
- FR-407: System shall track result acknowledgment: physician must review and acknowledge each result, signing indicates medical decision-making occurred, unacknowledged results appear in physician's inbox with aging
- FR-408: System shall support lab result trending: display sequential results for the same test in a table and graph, with reference range bands, across multiple ordering dates
- FR-409: System shall support LOINC coding for all lab orders and results for interoperability
- FR-410: System shall support in-house/point-of-care lab results: glucose meters, rapid strep, rapid flu, urinalysis — entered by nursing staff with device ID and QC tracking
- FR-411: System shall support lab order panels (groups of tests): Basic Metabolic Panel, Complete Blood Count, Lipid Panel, Thyroid Panel — with individual test result parsing from panel results
- FR-412: System shall generate lab requisition forms for patient walk-in at external lab, with patient demographics, ordering physician, clinical indication, and fasting instructions pre-populated

### 4.5 Billing & Revenue Cycle (FR-5xx)

- FR-501: System shall suggest CPT codes from clinical documentation using NLP: analyze assessment/plan text and recommend appropriate E&M level (99202-99215) based on 2021 E&M guidelines (MDM-based)
- FR-502: System shall perform real-time claim scrubbing before submission: ICD-CPT compatibility, medical necessity (LCD/NCD), modifier requirements, place of service, authorization on file, timely filing within payer deadline
- FR-503: System shall submit electronic claims via EDI 837P (professional) and 837I (institutional) to clearinghouse (Availity or Change Healthcare)
- FR-504: System shall process ERA/EOB (EDI 835) with automatic payment posting: match to claim, post insurance payment, calculate patient responsibility, apply contractual adjustments
- FR-505: System shall estimate patient responsibility at time of service: deductible remaining, copay amount, coinsurance percentage — using eligibility response data
- FR-506: System shall manage payment plans: configurable minimum payment, frequency (monthly/biweekly), interest (0% for plans < 12 months), auto-draft via stored payment method, delinquency workflow (reminder → warning → collections referral)
- FR-507: System shall integrate with payment processor (Stripe or equivalent) for: credit/debit card payments (in-office and online), ACH bank transfers, payment plan auto-processing, refund processing, PCI DSS compliance
- FR-508: System shall generate aging reports: 0-30, 31-60, 61-90, 91-120, 120+ day buckets by payer, by physician, by clinic, by patient — with drill-down to individual claims
- FR-509: System shall support denial management workflow: categorize denial reason (eligibility, authorization, coding, documentation, timely filing), assign to billing specialist, track appeal submission, track appeal outcome, report denial patterns
- FR-510: System shall support charge capture: charges auto-created from signed clinical notes (CPT from procedure documentation, E&M from visit documentation), nursing charges from vitals/injections, facility charges
- FR-511: System shall support superbill/encounter form generation: pre-populated with patient demographics, visit date, physician, with checkboxes for common CPT/ICD codes by specialty
- FR-512: System shall generate patient statements: monthly, itemized, showing insurance payments received, adjustments applied, and patient balance due — available via mail and patient portal
- FR-513: System shall support sliding fee scale for uninsured patients: discount percentage based on federal poverty level (100% FPL = 100% discount, 200% FPL = 75% discount, etc.)
- FR-514: System shall support prior authorization management: track authorization number, authorized services, number of visits authorized, expiration date, alert when nearing authorization limit
- FR-515: System shall support credentialing tracking per physician per insurance plan: application status, effective date, recredentialing due date, with alerts 90 days before expiration
- FR-516: System shall calculate and report financial KPIs: days in AR, net collection rate, denial rate by payer, clean claim rate, cost to collect, charge lag days

### 4.6 Patient Portal (FR-6xx)

- FR-601: System shall provide secure patient login with multi-factor authentication: email/password + SMS verification code, with biometric (fingerprint/face) option for mobile app
- FR-602: System shall display upcoming and past appointments with: date, time, provider name, clinic location, appointment type, and visit notes (after provider release)
- FR-603: System shall display lab results with: result values, reference ranges, abnormal flagging, trend charts, and plain-language explanations (e.g., "Your cholesterol is slightly above the recommended level")
- FR-604: System shall allow prescription refill requests: select from active medication list, choose pharmacy, submit to physician for approval, receive notification when approved and sent to pharmacy
- FR-605: System shall support secure asynchronous messaging with care team: patient sends message → routed to physician's inbox → physician responds → patient notified via email/push — with 48-hour response SLA tracking
- FR-606: System shall provide medical record download in USCDI v3 format (21st Century Cures Act compliance) and human-readable PDF format
- FR-607: System shall display billing statements and allow online payment via stored payment method or new card/bank account
- FR-608: System shall provide health education resources linked to patient's active diagnoses, using content from a curated medical library (Healthwise, Krames, or equivalent)
- FR-609: System shall support proxy access: parents/guardians for minors (under 18), legal guardians for incapacitated adults — with verification workflow and automatic proxy expiration at age 18
- FR-610: System shall display immunization history with upcoming/overdue immunization recommendations based on CDC schedule and patient age
- FR-611: System shall allow patients to update demographics (address, phone, email, pharmacy, insurance) with verification workflow before changes apply to medical record
- FR-612: System shall support pre-visit questionnaires: medical history forms, review of systems, PHQ-9 depression screening, pain assessments — completed before appointment and auto-imported into clinical note
- FR-613: System shall provide appointment self-scheduling (rules defined in FR-206)
- FR-614: System shall support telehealth visit launch from portal: join video visit directly from appointment screen, with pre-visit tech check (camera, microphone, bandwidth)
- FR-615: System shall support document upload: patients can upload insurance cards, ID photos, referral letters, outside medical records — routed to appropriate staff for processing
- FR-616: System shall display care plan summaries for chronic conditions with: treatment goals, action items, progress tracking, and next milestone dates

### 4.7 Reporting & Analytics (FR-7xx)

- FR-701: System shall provide real-time provider productivity dashboard: patients seen today/week/month, RVU generation, no-show rate, average visit duration, chart completion rate
- FR-702: System shall provide financial dashboard: daily charges, daily collections, payments by method, claim submission counts, denial counts, AR summary
- FR-703: System shall generate MIPS/MACRA quality measure reports for CMS submission: at minimum Quality, Promoting Interoperability, Improvement Activities, and Cost categories
- FR-704: System shall provide custom report builder: drag-and-drop field selection from any data domain, filters, grouping, sorting, calculated fields, with export to Excel, CSV, and PDF
- FR-705: System shall provide population health analytics: disease prevalence by diagnosis, preventive care gap analysis, risk stratification (using HCC risk scores), patient panels per physician
- FR-706: System shall provide operational metrics: average patient wait time (arrival to provider), appointment utilization rate, check-in processing time, staff productivity metrics
- FR-707: System shall provide automated scheduled reports: daily census, weekly financial summary, monthly quality dashboard, quarterly compliance report — emailed to configured recipients
- FR-708: System shall maintain a data warehouse/analytics layer separate from transactional database for reporting workloads
- FR-709: System shall provide clinical quality dashboards: diabetes management (% patients with HbA1c < 7%), hypertension control (% patients with BP < 140/90), cancer screening rates (mammography, colonoscopy, Pap smear), immunization rates
- FR-710: System shall provide referral tracking reports: referrals sent, referrals with appointments scheduled, referrals completed, referral leakage rate (patients seen by out-of-network specialists)

### 4.8 System Administration (FR-8xx)

- FR-801: System shall support role-based access control (RBAC) with minimum roles: System Administrator, Physician, Nurse, Medical Assistant, Front Desk, Billing Specialist, Lab Technician, Compliance Officer, Report Viewer, Patient (portal) — with customizable permissions per role and per clinic
- FR-802: System shall provide user provisioning workflow: request → manager approval → compliance verification → account creation → orientation checklist completion → access activation
- FR-803: System shall enforce password policy: minimum 14 characters, uppercase + lowercase + number + special character, no reuse of last 12 passwords, 90-day expiration, account lockout after 5 failed attempts (30-minute lockout)
- FR-804: System shall support SSO via SAML 2.0 or OIDC with Active Directory / Azure AD
- FR-805: System shall generate comprehensive audit logs for: all user logins (success and failure), all patient record access (view, create, modify, delete, print, export), all clinical note modifications, all billing transactions, all system configuration changes, all user permission changes
- FR-806: System shall support "break the glass" emergency access: when a user needs to access a patient record outside their normal permissions (e.g., emergency department), they can request emergency access with documented reason, which is logged and reported to compliance
- FR-807: System shall support configurable session timeout: default 15 minutes inactivity, overridable per role (e.g., physicians in procedure rooms may need 60 minutes), with warning prompt at 2 minutes before timeout
- FR-808: System shall support system-wide announcement broadcast: administrators can push messages to all users (e.g., "System maintenance tonight 10 PM - 2 AM")
- FR-809: System shall provide clinic/location management: add, modify, deactivate clinics with: name, address, phone, fax, NPI, tax ID, operating hours, appointment slots configuration, assigned physicians, available rooms and equipment
- FR-810: System shall support fee schedule management: CPT code → charge amount mapping per payer contract, with effective dates and version history

---

## 5. Non-Functional Requirements

### 5.1 Performance (NFR-1xx)
- NFR-101: Page load time under 2 seconds at 95th percentile
- NFR-102: Support 500 concurrent users across all clinics
- NFR-103: Search results returned within 500ms
- NFR-104: Support growth to 5M patient records through 2031
- NFR-105: System availability 99.9% (8.7 hours max downtime/year)
- NFR-106: Scheduled maintenance windows: Sundays 2-6 AM ET only
- NFR-107: Database backup RPO: 1 hour, RTO: 4 hours
- NFR-108: API response time under 200ms at 95th percentile

### 5.2 Security & Compliance (NFR-2xx)
- NFR-201: All data encrypted at rest (AES-256) and in transit (TLS 1.3)
- NFR-202: PHI fields additionally encrypted at column level in database
- NFR-203: HIPAA Security Rule compliance (administrative, physical, technical safeguards)
- NFR-204: HIPAA Privacy Rule compliance (minimum necessary, accounting of disclosures)
- NFR-205: HITECH Act compliance (breach notification procedures)
- NFR-206: 21st Century Cures Act compliance (information blocking prevention, USCDI support)
- NFR-207: Annual penetration testing by independent firm
- NFR-208: Quarterly vulnerability scanning
- NFR-209: BAA required with all third-party service providers accessing PHI
- NFR-210: Data retention: clinical records 10 years from last encounter (NC GS § 90-210.25A), billing records 7 years (federal), audit logs 6 years (HIPAA)

### 5.3 Integration Standards (NFR-3xx)
- NFR-301: HL7 FHIR R4 API for all clinical data exchange
- NFR-302: HL7 v2.5.1 support for legacy interface transition period
- NFR-303: SMART on FHIR authorization for third-party apps
- NFR-304: Direct Secure Messaging for provider-to-provider communication
- NFR-305: CCDA document generation and ingestion (CCD, Referral Note, Discharge Summary)
- NFR-306: ADT (Admit/Discharge/Transfer) message support for hospital integration

### 5.4 Accessibility (NFR-4xx)
- NFR-401: WCAG 2.1 AA compliance for all interfaces
- NFR-402: Section 508 compliance for government reporting interfaces
- NFR-403: Support for screen readers (JAWS, NVDA, VoiceOver)
- NFR-404: Keyboard-only navigation for all workflows
- NFR-405: Multi-language support: English and Spanish at minimum, with i18n framework for adding languages
- NFR-406: High-contrast mode and configurable font sizing

---

## 6. Data Migration Requirements

- DM-101: Migrate all 180,000 active patient demographic records
- DM-102: Migrate appointment history: 3 years (approximately 2.6M records)
- DM-103: Migrate clinical notes: all signed notes (approximately 4.2M records)
- DM-104: Migrate billing claims: 7 years (approximately 8.1M records)
- DM-105: Migrate lab results: 5 years (approximately 3.8M records)
- DM-106: Migrate medication lists: all active medications
- DM-107: Migrate allergy lists: all documented allergies
- DM-108: Migrate scanned documents: extract from database BLOBs to object storage
- DM-109: Convert SSN storage from plaintext to encrypted (AES-256, application-level)
- DM-110: Convert date strings ('MM/DD/YYYY') to proper datetime with timezone
- DM-111: Normalize ICD codes: map all ICD-9 codes to ICD-10 equivalents
- DM-112: Deduplicate patient records: estimated 3,200 duplicates based on SSN analysis
- DM-113: Data validation: 100% of migrated records pass referential integrity checks
- DM-114: Parallel run period: 30 days with both systems active
- DM-115: Staff verification: clinical leads validate migrated data for 100 randomly selected patients per clinic

---

## 7. Constraints & Assumptions

### Constraints
- C-01: Budget cap $1.2M (approved by board, no additional funding available)
- C-02: AWS deployment required (existing enterprise agreement, BAA in place)
- C-03: Must maintain uninterrupted patient care during entire migration
- C-04: Internal IT team of 4 available 50% for project support
- C-05: HIPAA audit scheduled September 2026 — encryption must be in place
- C-06: NC state regulations require 10-year clinical record retention
- C-07: 21st Century Cures Act compliance deadline applies immediately
- C-08: Three pilot clinics must go live before enterprise rollout

### Assumptions
- A-01: AWS BAA covers all PHI handling in cloud environment
- A-02: Existing Active Directory will be used for SSO
- A-03: LabCorp and Quest FHIR APIs are available for integration
- A-04: Physicians will adopt mobile access if provided
- A-05: Patient adoption of portal will reach 40% within first year
- A-06: Legacy vendor will provide read-only database access during parallel run

---

## 8. Risk Register

| ID | Risk | Prob | Impact | Mitigation |
|----|------|------|--------|------------|
| R-01 | Data migration data loss | Medium | Critical | Multiple validation passes, parallel run, rollback plan |
| R-02 | Staff resistance to change | High | High | Champion program, early involvement, phased training |
| R-03 | HIPAA compliance gaps | Low | Critical | Compliance consultant engaged from day 1 |
| R-04 | Lab integration delays | Medium | High | Early API access requests, manual fallback process |
| R-05 | Budget overrun | Medium | Medium | Fixed-price phases, change order process |
| R-06 | Timeline delay | High | Medium | Phased rollout, MVP-first approach |
| R-07 | Performance under load | Medium | High | Load testing at 150% projected peak, performance budget per page |
| R-08 | Physician adoption failure | Medium | High | Mobile-first design, physician champion program, scribes as backup |
| R-09 | Patient data breach during migration | Low | Critical | Encryption in transit, limited migration team access, background checks |
| R-10 | Legacy system failure during parallel run | Medium | Critical | Maintain current backup regime, define legacy incident response |

---

*Approved: Dr. James Wright (CMO), Sarah Chen (VP Product), Michael Torres (IT Director), Linda Park (Compliance)*
*Board approval date: March 15, 2026*
