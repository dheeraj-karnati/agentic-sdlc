# Stakeholder Meeting Notes — HealthTrack Pro Modernization
# Kickoff Meeting | March 3, 2026 | Raleigh HQ Conference Room B
# Attendees: Dr. Wright (CMO), Sarah Chen (VP Product), Michael Torres (IT), Linda Park (Compliance), Karen Davis (Head Nurse), Robert Kim (Billing), Dr. Patel (Physician Champion)

## Key Discussion Points

### Karen Davis (Nursing)
- "Scheduling is my biggest headache. 45 minutes every morning fixing double-bookings. Last week Dr. Martinez had 12 patients in a 4-hour block."
- Walk-in patients: "We write names on a whiteboard. There's no queue system."
- Waitlist: "Patients call for earlier appointments and we track it on sticky notes."
- Check-in: "We're still printing paper forms for demographics EVERY visit."
- Vital signs: "Nurses enter vitals, then the doctor can't see trends. It's just the latest numbers."
- "We need a status board — who's checked in, who's in a room, who's waiting."

### Robert Kim (Billing)
- "Denial rate is 18%. Industry average is 5-10%. Most denials: wrong diagnosis code, missing prior auth, or timely filing."
- "Real-time eligibility would save 15 minutes per patient. Staff currently calls each payer or checks their website."
- "Doctors write 'comprehensive visit' but bill 99213 when it should be 99214. We're losing $200K+ annually in undercoding."
- Payment plans tracked in Excel spreadsheet — 400+ rows, manual follow-up calls.
- "We need automatic charge capture from clinical notes. Right now billing manually reviews every note."
- IMPORTANT: Robert says approval threshold for high-dollar claims is $5,000. *** THIS CONTRADICTS THE BRD WHICH SAYS $10,000 ***

### Michael Torres (IT)
- "Database is 2.3 TB, growing 15 GB/month. 890 GB is scanned documents stored as BLOBs."
- "SQL Server 2008 R2 is completely unsupported. Can't patch CVEs."
- "SSNs in plaintext. I've raised this 4 times in 2 years. Class-action risk."
- Recommends AWS (existing agreement). NOT GCP — "none of my team has GCP experience."
- Wants Okta for SSO — "47 departed employee accounts still active in the legacy system."
- "We need connection pooling. Current system opens a new DB connection per page request."

### Linda Park (Compliance)
- HIPAA audit scheduled September 2026. "Encryption at rest MUST be in place by then."
- "Billing staff should not see clinical notes. That's a minimum necessary violation."
- Audit trail requirements: who accessed which patient, when, from where, what they did.
- Data retention: *** "Clinical records 10 years from last encounter per NC state law. NOT 7 years as stated in the BRD." *** Action item for Linda to send the statute reference.
- 21st Century Cures Act: patients must be able to download records in USCDI format.
- "Break the glass" access needed for emergencies — but MUST be logged and reviewed.
- Breach notification: must be able to identify all affected patients within 60 days of breach discovery.

### Dr. Wright (CMO)
- Two physicians threatened to leave without mobile access. "Dr. Patel reviews lab results between patients — needs her phone."
- HIPAA incident last month: nurse at Cary clinic accessed records of a personal acquaintance. No detection mechanism in legacy system.
- Wants telehealth in Phase 1. Sarah pushes back — too complex. Compromise: telehealth scheduling in Phase 1, video integration in Phase 2.
- "We need clinical decision support. A diabetic patient was missed for HbA1c screening for 18 months because there's no alert system."
- Controlled substance prescribing: "NC requires PDMP check before prescribing any Schedule II. Our system has no integration."

### Dr. Patel (Physician Champion)
- "I want to dictate notes on my phone and have them transcribed into the chart."
- "Show me lab results on a timeline, not a flat list. I need to see the trend."
- "Drug interaction alerts are critical. I almost prescribed a contraindicated medication last month because we have no checking system."
- "Note templates are too rigid. I need customizable templates per visit type."
- "The after-visit summary is confusing for patients. It needs plain language."

### Budget Discussion
- Total: $1.2M approved
- Development: $650K | AWS infra: $120K/yr | Migration: $80K | Training: $50K | Contingency: $150K | PM: $100K | Compliance consulting: $50K
- Robert's ROI argument: reducing denial rate from 18% to 5% recovers ~$400K/year. System pays for itself in 3 years.

## Action Items
| # | Action | Owner | Due |
|---|--------|-------|-----|
| 1 | Verify data retention: 7 vs 10 years | Linda | Mar 10 |
| 2 | Provision AWS dev/staging environment | Michael | Mar 17 |
| 3 | Get LabCorp and Quest API access | Sarah | Mar 15 |
| 4 | Identify 3 pilot clinics | Karen | Mar 10 |
| 5 | Draft data migration plan | Michael | Mar 24 |
| 6 | Clarify approval threshold ($5K vs $10K) | Robert + Sarah | Mar 10 |
| 7 | Engage compliance consultant | Linda | Mar 10 |
| 8 | Review PDMP integration options for NC and VA | Michael | Mar 17 |

## Parking Lot
- Hospital system integration (Epic/Cerner) — future phase
- Patient wearable data — future phase
- AI-assisted diagnosis — legal review needed
- Multi-language support beyond English/Spanish — assess patient demographics first
- Genetic/genomic data storage — future phase
