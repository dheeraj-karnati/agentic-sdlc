"""HealthTrack Pro Legacy Code — Patient & Scheduling Module
Rewritten from VB6 COM+ for analysis. Contains known bugs and vulnerabilities."""

import pyodbc
from datetime import datetime, timedelta

class PatientService:
    APPROVAL_THRESHOLD = 5000  # BRD says $10,000 — CONFLICT!

    def __init__(self, conn_str):
        self.conn_str = conn_str

    def search(self, term, clinic_id=None):
        """SQL INJECTION VULNERABILITY — string concatenation"""
        conn = pyodbc.connect(self.conn_str)
        q = f"SELECT TOP 50 * FROM patients WHERE active=1 AND (first_name LIKE '%{term}%' OR last_name LIKE '%{term}%' OR ssn LIKE '%{term}%')"
        if clinic_id: q += f" AND clinic_id={clinic_id}"
        return conn.cursor().execute(q).fetchall()

    def check_duplicate(self, first, last, dob, ssn4):
        """BRD says probabilistic matching — code does exact match only"""
        conn = pyodbc.connect(self.conn_str)
        return conn.cursor().execute(
            f"SELECT * FROM patients WHERE active=1 AND ((last_name='{last}' AND dob='{dob}') OR (RIGHT(ssn,4)='{ssn4}' AND dob='{dob}'))"
        ).fetchall()

    def register(self, data):
        """No validation on SSN format, no encryption, no duplicate check before insert"""
        conn = pyodbc.connect(self.conn_str)
        conn.cursor().execute(f"""INSERT INTO patients(first_name,last_name,dob,ssn,gender,phone_cell,email,insurance_id,clinic_id,created_by)
            VALUES('{data["first"]}','{data["last"]}','{data["dob"]}','{data["ssn"]}','{data["gender"]}','{data["phone"]}','{data["email"]}',{data["ins_id"]},{data["clinic_id"]},'SYSTEM')""")
        conn.commit()

class AppointmentScheduler:
    TYPES = {'NEW':60,'FOLLOWUP':30,'URGENT':15,'PROCEDURE':60,'TELEHEALTH':30,'ANNUAL':45}

    def __init__(self, conn_str):
        self.conn_str = conn_str

    def book(self, pid, phys_id, clinic_id, date, time, atype, reason):
        """BUG: Only checks exact time match, not duration overlap.
        If Dr. has 60-min appt at 9:00, this allows booking at 9:30."""
        conn = pyodbc.connect(self.conn_str)
        cur = conn.cursor()
        if cur.execute(f"SELECT 1 FROM appointments WHERE physician_id={phys_id} AND appt_date='{date}' AND appt_time='{time}' AND status NOT IN ('CANCELLED','NO_SHOW')").fetchone():
            return None, "Slot taken"
        dur = self.TYPES.get(atype, 30)
        cur.execute(f"INSERT INTO appointments(patient_id,physician_id,clinic_id,appt_date,appt_time,duration_minutes,appt_type,status,reason) VALUES({pid},{phys_id},{clinic_id},'{date}','{time}',{dur},'{atype}','SCHEDULED','{reason}')")
        conn.commit()
        return cur.execute("SELECT @@IDENTITY").fetchone()[0], "Booked"

    def get_schedule(self, phys_id, date):
        conn = pyodbc.connect(self.conn_str)
        return conn.cursor().execute(f"SELECT a.*,p.first_name+' '+p.last_name as name FROM appointments a JOIN patients p ON a.patient_id=p.patient_id WHERE a.physician_id={phys_id} AND CAST(a.appt_date AS DATE)='{date}' AND a.status<>'CANCELLED' ORDER BY a.appt_time").fetchall()

class BillingProcessor:
    CPT_MAP = {'NEW_LOW':'99201','NEW_MED':'99202','EST_LOW':'99211','EST_MED':'99212','EST_MOD':'99213','EST_HIGH':'99214'}  # 99201 DELETED in 2021!
    THRESHOLD = 5000  # $5K, not $10K per BRD — CONFLICT!

    def create_claim(self, appt_id, cpt, icds, charges):
        conn = pyodbc.connect(self.conn_str)
        cur = conn.cursor()
        appt = cur.execute(f"SELECT a.*,p.insurance_id FROM appointments a JOIN patients p ON a.patient_id=p.patient_id WHERE a.appt_id={appt_id}").fetchone()
        if not appt: return None, "Not found"
        if charges > self.THRESHOLD:
            print(f"WARNING: ${charges} exceeds ${self.THRESHOLD}")  # No actual approval workflow!
        icd_list = icds.split(',')
        cur.execute(f"INSERT INTO billing_claims(patient_id,appt_id,physician_id,service_date,cpt_code,icd_primary,icd_secondary,charges,balance,claim_status) VALUES({appt.patient_id},{appt_id},{appt.physician_id},'{appt.appt_date}','{cpt}','{icd_list[0]}','{','.join(icd_list[1:])}',{charges},{charges},'PENDING')")
        conn.commit()
        return cur.execute("SELECT @@IDENTITY").fetchone()[0], "Created"

    def nightly_batch(self):
        """Runs at 11 PM via Windows Task Scheduler. 150-200 claims/night. 18% denial rate."""
        conn = pyodbc.connect(self.conn_str)
        claims = conn.cursor().execute("SELECT c.*,p.ssn,p.insurance_member_id,i.payer_id FROM billing_claims c JOIN patients p ON c.patient_id=p.patient_id JOIN insurance_plans i ON p.insurance_id=i.insurance_id WHERE c.claim_status='PENDING'").fetchall()
        # Generate EDI 837P and SFTP to Availity
        return len(claims)

class LabProcessor:
    """All lab orders are fax-based. Results manually entered. 3.2% error rate."""
    def order_lab(self, patient_id, physician_id, tests, lab_company):
        conn = pyodbc.connect(self.conn_str)
        conn.cursor().execute(f"INSERT INTO lab_orders(patient_id,physician_id,tests_ordered,lab_company,status) VALUES({patient_id},{physician_id},'{tests}','{lab_company}','ORDERED')")
        conn.commit()
        # THEN: print order form, fax to lab company manually
        # No electronic interface!

    def enter_result(self, order_id, results_text, abnormal):
        """Manual entry from fax. Average 4-6 hours from lab completion."""
        conn = pyodbc.connect(self.conn_str)
        conn.cursor().execute(f"UPDATE lab_orders SET results_text='{results_text}',abnormal_flag='{abnormal}',status='RECEIVED',results_date=GETDATE() WHERE order_id={order_id}")
        conn.commit()
        # No notification to physician — they must check manually
