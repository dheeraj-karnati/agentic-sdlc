# Data Migration Analysis Report
# Author: Michael Torres, IT Director | Date: February 2026

## Source System Inventory

| Table | Rows | Size | Migration Priority |
|-------|------|------|--------------------|
| patients | 243,000 | 12 GB | P1 — Critical |
| appointments | 2.6M (3yr) | 120 GB | P1 — Critical |
| clinical_notes | 4.2M | 780 GB | P1 — Critical |
| billing_claims | 8.1M (7yr) | 45 GB | P1 — Critical |
| lab_orders | 3.8M (5yr) | 28 GB | P1 — Critical |
| medications | 890K | 4 GB | P1 — Critical |
| allergies | 156K | 1 GB | P1 — Critical |
| vitals | 5.2M | 15 GB | P1 — Critical |
| patient_documents | 8M | 890 GB | P2 — Extract from BLOB |
| audit_log | 95M | 340 GB | P3 — Archive only |

## Data Quality Issues

### Critical Issues
1. **12,400 patients** with NULL or invalid DOB ('00/00/0000', '01/01/1900')
2. **3,200 patients** with duplicate SSN values — shared insurance? data entry errors?
3. **847 patients** with no associated clinic_id (orphaned records)
4. **SSN format inconsistency**: mix of '123-45-6789', '123456789', and '12345-6789'
5. **ICD code migration**: 680,000 clinical notes use ICD-9 (pre-Oct 2015), rest ICD-10
6. **50,000 clinical notes** have full_text populated but SOAP fields (subjective/objective/assessment/plan) are NULL — entered via legacy freetext form

### Data Integrity Issues
7. **Phone numbers**: 15% in inconsistent formats ((919)555-1234 vs 919-555-1234 vs 9195551234)
8. **Email addresses**: only 30% populated, 8% of those invalid format
9. **Zip codes**: 2% have 9-digit format without hyphen, 0.5% have non-US formats
10. **Gender field**: uses CHAR(1) — 'M','F', NULL — does not capture gender identity
11. **Race/ethnicity**: uses free-text VARCHAR, not coded — 47 distinct values including typos

### Referential Integrity
12. **4,200 appointments** reference physician_id that no longer exists in physicians table
13. **1,100 billing claims** reference appt_id that doesn't exist (deleted appointments)
14. **23,000 lab orders** have physician_id=0 (system-generated orders)

## Migration Strategy

### Phase 1: Active Data (72-hour window)
- Migrate 180,000 active patients + current year data
- Clean data in staging: fix DOBs, normalize SSN format, encrypt
- Map ICD-9 to ICD-10 using CMS General Equivalence Mappings
- Convert VARCHAR dates to proper DATETIME with timezone (America/New_York)
- Extract documents from BLOB to S3 with patient_id reference

### Phase 2: Historical Data (background, 2 weeks)
- Migrate 3 years appointments, 7 years billing, 5 years labs
- Lower priority — can run while new system is live

### Phase 3: Archive & Decommission (30 days post-go-live)
- Archive audit_log to cold storage (S3 Glacier)
- Maintain read-only legacy access for 90 days
- Full decommission after parallel validation

### Rollback Plan
- Maintain nightly sync from new system back to legacy for first 30 days
- If critical failure: revert DNS, restore from legacy backup, max 4-hour RTO
