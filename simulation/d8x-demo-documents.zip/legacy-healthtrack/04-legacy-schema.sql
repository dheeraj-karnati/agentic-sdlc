-- HealthTrack Pro Legacy Database Schema (SQL Server 2008 R2)
-- 14 tables, 243K patients, 2.3 TB total

CREATE TABLE clinics (
    clinic_id INT IDENTITY(1,1) PRIMARY KEY,
    clinic_name VARCHAR(100) NOT NULL, address1 VARCHAR(100), city VARCHAR(50),
    state CHAR(2), zip VARCHAR(10), phone VARCHAR(20), fax VARCHAR(20),
    npi VARCHAR(10), tax_id VARCHAR(15), active BIT DEFAULT 1, created_date DATETIME DEFAULT GETDATE());

CREATE TABLE physicians (
    physician_id INT IDENTITY(1,1) PRIMARY KEY,
    first_name VARCHAR(50), last_name VARCHAR(50), npi VARCHAR(10) NOT NULL,
    specialty VARCHAR(50), clinic_id INT REFERENCES clinics(clinic_id),
    dea_number VARCHAR(20), license_state CHAR(2), license_number VARCHAR(20),
    email VARCHAR(100), active BIT DEFAULT 1);

CREATE TABLE users (
    user_id INT IDENTITY(1,1) PRIMARY KEY,
    username VARCHAR(50) UNIQUE, password_hash VARCHAR(32), -- MD5, NO SALT!
    role VARCHAR(20), -- only 'ADMIN','DOCTOR','STAFF' -- too few roles
    physician_id INT REFERENCES physicians(physician_id),
    clinic_id INT REFERENCES clinics(clinic_id), active BIT DEFAULT 1,
    last_login DATETIME, failed_attempts INT DEFAULT 0);

CREATE TABLE patients (
    patient_id INT IDENTITY(1,1) PRIMARY KEY,
    first_name VARCHAR(50), last_name VARCHAR(50), middle_name VARCHAR(50),
    dob VARCHAR(10), -- STORED AS STRING 'MM/DD/YYYY' !!
    ssn VARCHAR(11), -- PLAINTEXT SSN !!
    gender CHAR(1), race VARCHAR(30), ethnicity VARCHAR(30),
    address1 VARCHAR(100), city VARCHAR(50), state CHAR(2), zip VARCHAR(10),
    phone_home VARCHAR(20), phone_cell VARCHAR(20), email VARCHAR(100),
    emergency_contact_name VARCHAR(100), emergency_contact_phone VARCHAR(20),
    insurance_id INT, insurance_group VARCHAR(50), insurance_member_id VARCHAR(50),
    primary_physician_id INT REFERENCES physicians(physician_id),
    clinic_id INT REFERENCES clinics(clinic_id),
    active BIT DEFAULT 1, deceased BIT DEFAULT 0,
    created_date DATETIME DEFAULT GETDATE(), modified_date DATETIME,
    created_by VARCHAR(50), modified_by VARCHAR(50));

CREATE TABLE appointments (
    appt_id INT IDENTITY(1,1) PRIMARY KEY,
    patient_id INT REFERENCES patients(patient_id),
    physician_id INT REFERENCES physicians(physician_id),
    clinic_id INT REFERENCES clinics(clinic_id),
    appt_date DATETIME, appt_time VARCHAR(8), -- 'HH:MM AM' STRING!
    duration_minutes INT DEFAULT 30,
    appt_type VARCHAR(20), -- 'NEW','FOLLOWUP','URGENT','PROCEDURE'
    status VARCHAR(20) DEFAULT 'SCHEDULED',
    reason VARCHAR(200), notes TEXT, room_number VARCHAR(10),
    check_in_time DATETIME, check_out_time DATETIME,
    copay_amount MONEY, copay_collected BIT DEFAULT 0);

CREATE TABLE clinical_notes (
    note_id INT IDENTITY(1,1) PRIMARY KEY,
    patient_id INT REFERENCES patients(patient_id),
    physician_id INT REFERENCES physicians(physician_id),
    appt_id INT REFERENCES appointments(appt_id),
    note_type VARCHAR(20), note_date DATETIME DEFAULT GETDATE(),
    subjective NVARCHAR(MAX), objective NVARCHAR(MAX),
    assessment NVARCHAR(MAX), plan NVARCHAR(MAX),
    full_text NVARCHAR(MAX), -- REDUNDANT with above
    icd_codes VARCHAR(500), -- COMMA-SEPARATED!
    cpt_codes VARCHAR(500), -- COMMA-SEPARATED!
    signed BIT DEFAULT 0, signed_date DATETIME, signed_by VARCHAR(50),
    cosigned BIT DEFAULT 0, cosigned_by VARCHAR(50),
    addendum_to INT REFERENCES clinical_notes(note_id));

CREATE TABLE medications (
    med_id INT IDENTITY(1,1) PRIMARY KEY,
    patient_id INT REFERENCES patients(patient_id),
    drug_name VARCHAR(200), dosage VARCHAR(100), frequency VARCHAR(100),
    route VARCHAR(50), prescribing_physician_id INT REFERENCES physicians(physician_id),
    start_date DATETIME, end_date DATETIME,
    status VARCHAR(20) DEFAULT 'ACTIVE', refills_remaining INT DEFAULT 0,
    pharmacy VARCHAR(200), ndc_code VARCHAR(20), is_controlled BIT DEFAULT 0);

CREATE TABLE allergies (
    allergy_id INT IDENTITY(1,1) PRIMARY KEY,
    patient_id INT REFERENCES patients(patient_id),
    allergen VARCHAR(200), reaction VARCHAR(200),
    severity VARCHAR(20), -- MILD/MODERATE/SEVERE/LIFE_THREATENING
    verified BIT DEFAULT 0);

CREATE TABLE lab_orders (
    order_id INT IDENTITY(1,1) PRIMARY KEY,
    patient_id INT REFERENCES patients(patient_id),
    physician_id INT REFERENCES physicians(physician_id),
    order_date DATETIME DEFAULT GETDATE(),
    lab_company VARCHAR(50), tests_ordered VARCHAR(1000), -- COMMA-SEPARATED!
    clinical_indication VARCHAR(500), priority VARCHAR(20) DEFAULT 'ROUTINE',
    status VARCHAR(20) DEFAULT 'ORDERED',
    results_text NVARCHAR(MAX), -- UNSTRUCTURED free text
    abnormal_flag CHAR(1) DEFAULT 'N', critical_flag CHAR(1) DEFAULT 'N',
    reviewed_by VARCHAR(50), reviewed_date DATETIME);

CREATE TABLE vitals (
    vital_id INT IDENTITY(1,1) PRIMARY KEY,
    patient_id INT REFERENCES patients(patient_id),
    appt_id INT REFERENCES appointments(appt_id),
    recorded_date DATETIME DEFAULT GETDATE(), recorded_by VARCHAR(50),
    height_inches DECIMAL(5,1), weight_lbs DECIMAL(5,1), bmi DECIMAL(4,1),
    blood_pressure_systolic INT, blood_pressure_diastolic INT,
    heart_rate INT, respiratory_rate INT, temperature DECIMAL(4,1),
    oxygen_saturation DECIMAL(4,1), pain_level INT);

CREATE TABLE billing_claims (
    claim_id INT IDENTITY(1,1) PRIMARY KEY,
    patient_id INT REFERENCES patients(patient_id),
    appt_id INT REFERENCES appointments(appt_id),
    physician_id INT REFERENCES physicians(physician_id),
    service_date DATETIME, cpt_code VARCHAR(10), modifier VARCHAR(10),
    icd_primary VARCHAR(10), icd_secondary VARCHAR(100), -- COMMA-SEPARATED
    charges MONEY, allowed_amount MONEY, insurance_paid MONEY DEFAULT 0,
    patient_paid MONEY DEFAULT 0, adjustment MONEY DEFAULT 0, balance MONEY,
    claim_status VARCHAR(20) DEFAULT 'PENDING',
    denial_reason VARCHAR(500), batch_id INT);

CREATE TABLE patient_documents (
    doc_id INT IDENTITY(1,1) PRIMARY KEY,
    patient_id INT REFERENCES patients(patient_id),
    doc_type VARCHAR(50), doc_name VARCHAR(200),
    doc_content VARBINARY(MAX), -- BLOB IN DB!
    content_type VARCHAR(50), file_size INT,
    uploaded_by VARCHAR(50), upload_date DATETIME DEFAULT GETDATE());

-- VULNERABLE stored procedure
CREATE PROCEDURE sp_SearchPatients @SearchTerm VARCHAR(100) AS
BEGIN
    EXEC('SELECT TOP 50 * FROM patients WHERE active=1 AND (first_name LIKE ''%'+@SearchTerm+'%'' OR last_name LIKE ''%'+@SearchTerm+'%'' OR ssn LIKE ''%'+@SearchTerm+'%'')')
END

-- Appointment scheduling - BUG: doesn't check duration overlap
CREATE PROCEDURE sp_BookAppointment @PatientID INT, @PhysicianID INT, @Date DATETIME, @Time VARCHAR(8), @Type VARCHAR(20) AS
BEGIN
    IF EXISTS (SELECT 1 FROM appointments WHERE physician_id=@PhysicianID AND appt_date=@Date AND appt_time=@Time AND status NOT IN ('CANCELLED','NO_SHOW'))
        RAISERROR('Slot taken',16,1)
    ELSE
        INSERT INTO appointments(patient_id,physician_id,appt_date,appt_time,appt_type,status) VALUES(@PatientID,@PhysicianID,@Date,@Time,@Type,'SCHEDULED')
END
